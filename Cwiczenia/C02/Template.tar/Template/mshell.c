#define _POSIX_SOURCE 1

#include <stdio.h>

#include "config.h"
#include "commands.h"
#include "cparse.h"

int main(int, char**);

char prompt[10]=PROMPT;

/*
 * main
 */

char input_buf[BUFF_SIZE+1];

int main(argc, argv)
int argc;
char* argv[];
{
	printf("Exit.\n");
	return 0;
}

