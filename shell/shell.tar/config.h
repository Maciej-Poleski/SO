
#define BUFF_SIZE 2048
/* POSIX.2 (Shell and Utilities) allows for lines of 2048 bytes */

#define EXIT "exit"

#define RERROR_COM "Read error.\n"

#define MAX_COMMANDS 10
#define MAX_ARGS 10

#define PROMPT ">"

