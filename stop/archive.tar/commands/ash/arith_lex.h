/*
arith_lex.h

Created:	July 1995 by Philip Homburg <philip@cs.vu.nl>
*/

int yylex(void);
void arith_lex_reset(void);

/*
 * $PchId: arith_lex.h,v 1.1 2001/05/18 19:57:55 philip Exp $
 */
