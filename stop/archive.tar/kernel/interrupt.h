#ifndef __INTERRUPT_H__
#define __INTERRUPT_H__

#include "hw_intr.h"

#endif /* __INTERRUPT_H__ */
