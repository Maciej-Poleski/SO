#include "kernel.h"

DEFINE_CPULOCAL_VARS;
